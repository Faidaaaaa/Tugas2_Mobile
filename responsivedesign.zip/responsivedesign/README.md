# RESPONSIVE DESIGN x FLUTTER

Check out my tutorial if you need: https://youtu.be/MrPJBAOzKTQ

![179F6FDC-6794-4B62-AE3C-8F8166AC6757](https://user-images.githubusercontent.com/29016489/144535400-c7e4ce1f-ad79-4048-8d58-fbfa0cdc46ff.JPG)
