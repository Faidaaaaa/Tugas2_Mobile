// set the common device dimensions here for mobile / tablet / desktop

const mobileWidth = 600;
