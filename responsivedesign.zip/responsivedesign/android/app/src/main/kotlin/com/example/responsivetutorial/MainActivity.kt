package com.example.responsivetutorial

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
